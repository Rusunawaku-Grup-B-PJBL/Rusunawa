<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreAnnouncementRequest;
use App\Http\Requests\UpdateDamageReportRequest;
use App\Http\Requests\UpdatePaymentRequest;
use App\Http\Resources\BookingResource;
use App\Http\Resources\DamageReportResource;
use App\Models\Announcement;
use App\Models\Booking;
use App\Models\DamageReport;
use Illuminate\Http\JsonResponse;

class AdminController extends Controller
{
    public function bookings(): JsonResponse
    {
        $bookings = Booking::query()
            ->with(['room', 'handovers'])
            ->orderByDesc('created_at')
            ->get()
            ->map(fn (Booking $booking) => (new BookingResource($booking))->resolve());

        return response()->json(['data' => $bookings]);
    }

    public function damageReports(): JsonResponse
    {
        $reports = DamageReport::query()
            ->with(['room', 'logs'])
            ->orderByDesc('created_at')
            ->get()
            ->map(fn (DamageReport $report) => (new DamageReportResource($report))->resolve());

        return response()->json(['data' => $reports]);
    }

    public function updatePayment(UpdatePaymentRequest $request, Booking $booking): JsonResponse
    {
        $booking->update($request->validated());
        $booking->load(['room', 'handovers']);

        return response()->json([
            'message' => 'Status pembayaran berhasil diperbarui.',
            'data' => (new BookingResource($booking))->resolve(),
        ]);
    }

    public function updateDamageReport(
        UpdateDamageReportRequest $request,
        DamageReport $damageReport,
    ): JsonResponse {
        $data = $request->validated();
        $damageReport->update(array_intersect_key($data, array_flip(['status', 'technician_name'])));

        $damageReport->logs()->create([
            'status' => $damageReport->status,
            'note' => $data['note'] ?? null,
        ]);

        $damageReport->load(['room', 'logs']);

        return response()->json([
            'message' => 'Laporan kerusakan berhasil diperbarui.',
            'data' => (new DamageReportResource($damageReport))->resolve(),
        ]);
    }

    public function storeAnnouncement(StoreAnnouncementRequest $request): JsonResponse
    {
        $announcement = Announcement::create($request->validated());

        return response()->json([
            'message' => 'Pengumuman berhasil diterbitkan.',
            'data' => [
                'id' => $announcement->id,
                'title' => $announcement->title,
                'body' => $announcement->body,
                'published_at' => $announcement->published_at?->toISOString(),
            ],
        ], 201);
    }
}
